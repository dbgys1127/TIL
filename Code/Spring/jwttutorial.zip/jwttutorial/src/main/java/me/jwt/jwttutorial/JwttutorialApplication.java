package me.jwt.jwttutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwttutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwttutorialApplication.class, args);
	}

}
