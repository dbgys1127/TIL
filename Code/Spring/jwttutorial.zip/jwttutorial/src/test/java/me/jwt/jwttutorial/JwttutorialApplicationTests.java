package me.jwt.jwttutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwttutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
