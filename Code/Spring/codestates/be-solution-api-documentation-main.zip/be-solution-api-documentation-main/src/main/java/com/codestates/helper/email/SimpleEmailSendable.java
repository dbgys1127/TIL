package com.codestates.helper.email;

public class SimpleEmailSendable implements EmailSendable {
    @Override
    public void send(String message) {
        // TODO 간단한 문자열 형태의 이메일 구현에 대한 로직을 구성할 수 있습니다.
    }
}
