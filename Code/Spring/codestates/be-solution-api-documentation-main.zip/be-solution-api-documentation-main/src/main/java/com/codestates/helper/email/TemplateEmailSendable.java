package com.codestates.helper.email;

public class TemplateEmailSendable implements EmailSendable {
    @Override
    public void send(String message) {
        // TODO 템플릿을 사용한 이메일을 보낼 수 있습니다.
    }
}
