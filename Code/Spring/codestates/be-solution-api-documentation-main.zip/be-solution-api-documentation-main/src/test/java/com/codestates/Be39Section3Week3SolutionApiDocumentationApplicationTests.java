package com.codestates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Be39Section3Week3SolutionApiDocumentationApplicationTests {

	@Test
	void contextLoads() {
	}

}
