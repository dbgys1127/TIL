package solo.todoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToDoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
